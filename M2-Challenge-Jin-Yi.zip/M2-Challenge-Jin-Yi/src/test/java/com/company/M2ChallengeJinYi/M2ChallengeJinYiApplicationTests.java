package com.company.M2ChallengeJinYi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class M2ChallengeJinYiApplicationTests {

	@Test
	void contextLoads() {
	}

}
