package com.company.M2ChallengeJinYi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class M2ChallengeJinYiApplication {

	public static void main(String[] args) {
		SpringApplication.run(M2ChallengeJinYiApplication.class, args);
	}

}
